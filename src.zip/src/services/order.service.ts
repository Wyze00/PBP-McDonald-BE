

export class  {
    constructor(parameters) {
        
    }
}